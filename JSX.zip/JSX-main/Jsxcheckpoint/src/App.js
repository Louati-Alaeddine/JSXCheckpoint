
import './App.css';
import './style.css'
function App() {
  return (
    <div className="container">

<div style={{border:"solid 1px black",maxWidth:"100vw"}}/>

<h1 className="title red"> Louati Alaeddine </h1>

<br />

<img src="/imageInSrc.jpg"/>

<br />

<img src="/imageInPublic.jpg"/>

<br />

<iframe title="react video" width="560" height="315" src="https://www.youtube.com/embed/N3AkSS5hXMA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


    </div>
  );
}

export default App;
